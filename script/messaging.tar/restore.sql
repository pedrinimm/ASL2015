--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.messages DROP CONSTRAINT "messages_qId_fkey";
DROP INDEX public."index_uID";
DROP INDEX public.index_receiver;
DROP INDEX public."index_queId";
DROP INDEX public.index_q;
DROP INDEX public."index_mId";
ALTER TABLE ONLY public.users DROP CONSTRAINT "users_userId_key";
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_name_key;
ALTER TABLE ONLY public.queues DROP CONSTRAINT "queues_queueId_key";
ALTER TABLE ONLY public.queues DROP CONSTRAINT queues_pkey;
ALTER TABLE ONLY public.messages DROP CONSTRAINT messages_pkey;
ALTER TABLE ONLY public.messages DROP CONSTRAINT "messages_messageObId_key";
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.queues ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.messages ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.queues_id_seq;
DROP TABLE public.queues;
DROP SEQUENCE public.messages_id_seq;
DROP FUNCTION public.insert_new_user(_name text, _userid text);
DROP FUNCTION public.insert_new_queue(_queuename text, _queueid text, _timestamp text);
DROP FUNCTION public.insert_new_message(_message text, _sender text, _receiver text, _messageoid text, _timestamp text, _qid text);
DROP FUNCTION public.get_users_id(_name text);
DROP FUNCTION public.get_queue_id(_name text);
DROP FUNCTION public.get_message_own(_namereceiver text);
DROP FUNCTION public.get_message_from(_namereceiver text, _namesender text);
DROP FUNCTION public.get_message_from(_namesender text);
DROP FUNCTION public.get_message(_receiver text);
DROP FUNCTION public.get_message();
DROP TABLE public.messages;
DROP FUNCTION public.delete_user(_name text);
DROP FUNCTION public.delete_queue(_name text);
DROP FUNCTION public.delete_messages_from_queue(_qid text);
DROP FUNCTION public.delete_message(_messageid text);
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: delete_message(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION delete_message(_messageid text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
 DELETE FROM messages WHERE messageobid=_messageid;
END;
$$;


ALTER FUNCTION public.delete_message(_messageid text) OWNER TO postgres;

--
-- Name: delete_messages_from_queue(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION delete_messages_from_queue(_qid text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN

	DELETE FROM messages WHERE qid=_qid;
END;
$$;


ALTER FUNCTION public.delete_messages_from_queue(_qid text) OWNER TO postgres;

--
-- Name: delete_queue(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION delete_queue(_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
 DELETE FROM queues WHERE queuename=_name;
END;
$$;


ALTER FUNCTION public.delete_queue(_name text) OWNER TO postgres;

--
-- Name: delete_user(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION delete_user(_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
 DELETE FROM users WHERE name=_name;
END;
$$;


ALTER FUNCTION public.delete_user(_name text) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE messages (
    message text,
    sender text NOT NULL,
    receiver text,
    messageobid text NOT NULL,
    "timestamp" text,
    qid text NOT NULL,
    id integer NOT NULL
);


ALTER TABLE messages OWNER TO postgres;

--
-- Name: get_message(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION get_message() RETURNS SETOF messages
    LANGUAGE plpgsql
    AS $$
BEGIN
 RETURN QUERY
	SELECT * FROM messages LIMIT 1;
	IF NOT FOUND THEN
		RETURN NEXT ROW(''::text,''::text,''::text,''::text,''::text,''::text,1::integer);
		--RAISE EXCEPTION 'No message';
	END IF;
END;
$$;


ALTER FUNCTION public.get_message() OWNER TO postgres;

--
-- Name: get_message(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION get_message(_receiver text) RETURNS SETOF messages
    LANGUAGE plpgsql
    AS $$
BEGIN
 RETURN QUERY
	SELECT * FROM messages WHERE receiver='' OR receiver=_receiver LIMIT 1;
	IF NOT FOUND THEN
		RETURN NEXT ROW(''::text,''::text,''::text,''::text,''::text,''::text,1::integer);
--		RAISE EXCEPTION 'No message';
	END IF;
END;
$$;


ALTER FUNCTION public.get_message(_receiver text) OWNER TO postgres;

--
-- Name: get_message_from(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION get_message_from(_namesender text) RETURNS SETOF messages
    LANGUAGE plpgsql
    AS $$
BEGIN
 RETURN QUERY
	SELECT * FROM messages WHERE sender=_namesender LIMIT 1;
	IF NOT FOUND THEN
		RETURN NEXT ROW(''::text,''::text,''::text,''::text,''::text,''::text,1::integer);
		--RAISE EXCEPTION 'No message';
	END IF;
END;
$$;


ALTER FUNCTION public.get_message_from(_namesender text) OWNER TO postgres;

--
-- Name: get_message_from(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION get_message_from(_namereceiver text, _namesender text) RETURNS SETOF messages
    LANGUAGE plpgsql
    AS $$
BEGIN
 RETURN QUERY
	SELECT * FROM messages WHERE (sender=_namesender AND receiver=_namereceiver) OR (sender=_namesender AND receiver='') LIMIT 1;
	IF NOT FOUND THEN

		RETURN NEXT ROW(''::text,''::text,''::text,''::text,''::text,''::text,1::integer);
		--RAISE EXCEPTION 'No message';
	END IF;
END;
$$;


ALTER FUNCTION public.get_message_from(_namereceiver text, _namesender text) OWNER TO postgres;

--
-- Name: get_message_own(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION get_message_own(_namereceiver text) RETURNS SETOF messages
    LANGUAGE plpgsql
    AS $$
BEGIN
 RETURN QUERY
	SELECT * FROM messages WHERE receiver=_namereceiver LIMIT 1;
	IF NOT FOUND THEN
		RETURN NEXT ROW(''::text,''::text,''::text,''::text,''::text,''::text,1::integer);
		--RAISE EXCEPTION 'No message';
	END IF;
END;
$$;


ALTER FUNCTION public.get_message_own(_namereceiver text) OWNER TO postgres;

--
-- Name: get_queue_id(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION get_queue_id(_name text) RETURNS text
    LANGUAGE sql
    AS $_$

	SELECT queueid FROM queues WHERE queuename=$1;

$_$;


ALTER FUNCTION public.get_queue_id(_name text) OWNER TO postgres;

--
-- Name: get_users_id(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION get_users_id(_name text) RETURNS text
    LANGUAGE sql
    AS $_$
	SELECT userid FROM users WHERE name=$1;
$_$;


ALTER FUNCTION public.get_users_id(_name text) OWNER TO postgres;

--
-- Name: insert_new_message(text, text, text, text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION insert_new_message(_message text, _sender text, _receiver text, _messageoid text, _timestamp text, _qid text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	INSERT INTO messages(message, sender, receiver, messageobid, timestamp, qid) VALUES(_message, _sender, _receiver, _messageoid, _timestamp, _qid);
END;
$$;


ALTER FUNCTION public.insert_new_message(_message text, _sender text, _receiver text, _messageoid text, _timestamp text, _qid text) OWNER TO postgres;

--
-- Name: insert_new_queue(text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION insert_new_queue(_queuename text, _queueid text, _timestamp text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	INSERT INTO queues(queuename,queueid, timestamp) VALUES(_queuename,_queueid,_timestamp);
END;
$$;


ALTER FUNCTION public.insert_new_queue(_queuename text, _queueid text, _timestamp text) OWNER TO postgres;

--
-- Name: insert_new_user(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION insert_new_user(_name text, _userid text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	INSERT INTO users(name, userid) VALUES(_name,_userID);
END;
$$;


ALTER FUNCTION public.insert_new_user(_name text, _userid text) OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE messages_id_seq OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE messages_id_seq OWNED BY messages.id;


--
-- Name: queues; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE queues (
    queueid text NOT NULL,
    "timestamp" text,
    queuename text,
    id integer NOT NULL
);


ALTER TABLE queues OWNER TO postgres;

--
-- Name: queues_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE queues_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE queues_id_seq OWNER TO postgres;

--
-- Name: queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE queues_id_seq OWNED BY queues.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    name text,
    userid text
);


ALTER TABLE users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY messages ALTER COLUMN id SET DEFAULT nextval('messages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY queues ALTER COLUMN id SET DEFAULT nextval('queues_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY messages (message, sender, receiver, messageobid, "timestamp", qid, id) FROM stdin;
\.
COPY messages (message, sender, receiver, messageobid, "timestamp", qid, id) FROM '$$PATH$$/2308.dat';

--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('messages_id_seq', 12053, true);


--
-- Data for Name: queues; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY queues (queueid, "timestamp", queuename, id) FROM stdin;
\.
COPY queues (queueid, "timestamp", queuename, id) FROM '$$PATH$$/2309.dat';

--
-- Name: queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('queues_id_seq', 35, true);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users (id, name, userid) FROM stdin;
\.
COPY users (id, name, userid) FROM '$$PATH$$/2312.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('users_id_seq', 17, true);


--
-- Name: messages_messageObId_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY messages
    ADD CONSTRAINT "messages_messageObId_key" UNIQUE (messageobid);


--
-- Name: messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: queues_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY queues
    ADD CONSTRAINT queues_pkey PRIMARY KEY (id);


--
-- Name: queues_queueId_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY queues
    ADD CONSTRAINT "queues_queueId_key" UNIQUE (queueid);


--
-- Name: users_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_name_key UNIQUE (name);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users_userId_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT "users_userId_key" UNIQUE (userid);


--
-- Name: index_mId; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "index_mId" ON messages USING btree (messageobid NULLS FIRST);


--
-- Name: index_q; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX index_q ON messages USING btree (qid);


--
-- Name: index_queId; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "index_queId" ON queues USING btree (queueid NULLS FIRST);


--
-- Name: index_receiver; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX index_receiver ON messages USING btree (receiver);


--
-- Name: index_uID; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "index_uID" ON users USING btree (userid NULLS FIRST);


--
-- Name: messages_qId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY messages
    ADD CONSTRAINT "messages_qId_fkey" FOREIGN KEY (qid) REFERENCES queues(queueid);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

